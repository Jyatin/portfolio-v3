Drop the two paper figures here with these exact filenames and the
Research Foundation section on the home page will render them automatically
— no code change needed:

  paper-page.png        a representative page from the submitted paper
  scenarios-figure.png  the paper's own figure for the four 2030 scenarios

Referenced from: src/data/paper.ts -> PAPER_FIGURES
Rendered in:     src/app/page.tsx -> TraceabilityPreview()
